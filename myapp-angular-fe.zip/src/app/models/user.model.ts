export class User {
    id?: any;
    fname?: string;
    user_name?: string;
    email?: string;
    status?: boolean;
  }