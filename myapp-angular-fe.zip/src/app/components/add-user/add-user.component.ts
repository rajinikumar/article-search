import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {

  user: User = {
    fname: '',
    user_name: '',
    email: '',
    status: false
  };
  submitted = false;
  constructor(private userService: UserService) { }
  ngOnInit(): void {
  }
  saveUser(): void {
    const data = {
      fname: this.user.fname,
      user_name: this.user.user_name,
      email: this.user.email
    };
    this.userService.create(data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.submitted = true;
        },
        error: (e) => console.error(e)
      });
  }
  newUser(): void {
    this.submitted = false;
    this.user = {
      fname: '',
      user_name: '',
      email: '',
      status: false
    };
  }
}
