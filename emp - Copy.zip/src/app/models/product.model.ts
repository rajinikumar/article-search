export class Product {
    price_adjuster?: String;
    execution?: String;
    lock_type?: String;
    have_comments?: Boolean;
    comments?: String
}
