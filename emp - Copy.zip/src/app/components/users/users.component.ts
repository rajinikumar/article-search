import { Component, OnInit } from '@angular/core';
import {ProductsService} from 'src/app/service/products.service';
import {Product} from 'src/app/models/product.model';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  products?: Product[];

  constructor(private productsService : ProductsService) { }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts():void {
    this.productsService.getMockAll().subscribe({
      next: (data) => {
        this.products = data
        console.log(data)
      },
      error: (e) => {
        console.log(e);
      }
    })
  }

}
